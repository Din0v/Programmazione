è la disciplina che si occupa della classificazione gerarchica di elementi. 



### Tags
#Databases 