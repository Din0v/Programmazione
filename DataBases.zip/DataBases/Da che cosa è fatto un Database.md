# Da che cosa è fatto un Database ?
1. [[Tables]]
2. [[Keys]]
3. [[Relationships]]
4. [[Normalization]]
5. [[Query Language]] che è abbastanza ovvio 

### Tags 
#Databases