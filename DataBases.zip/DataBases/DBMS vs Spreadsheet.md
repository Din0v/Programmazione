# La differenza tra Databasi e un excel. 

in a spreadsheet, data is stored in a cell, it can be formatted, editted and manipulated in the context of that cell 

in a database cells contain **records** that come from external tables 



### Tags 
#Databases