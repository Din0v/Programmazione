# Relational Database Manegment System 

1. it allows to do fancy querring 
2. it allows for differnt kinds to display the data _Si chiamano_: ***view mechanisms*** 
		-  la view mechanism permette di scombinare una tabella e dare il controllo solo in parte ad un amminsitratore, in base al suo ruolo, o posizione nella gerarchia.
3.  it does a [[Transaction in DBMS]]
4. we can have consistency on the forntend, and things can change on the backend 


### Tags 
#Databases