# perché si chiamano Relational Databases ?

Per il semplice fatto che questo tipo di dati di base usa la [Algebra Relazionale](https://www.tutorialspoint.com/dbms/relational_algebra.htm)


### Tags 
#Databases