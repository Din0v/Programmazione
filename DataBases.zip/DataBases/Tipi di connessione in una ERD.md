# Entity relationship diagram 
[[Entity relationship diagram ]] 
![[Pasted image 20230505143902.png]]
questo è il tipo di connessione tra i le diverse entità nell diagramma relazionale. 

check [[Relationships]]
### TAGS
#EDR
#DBMS



### Tags 
#Databases