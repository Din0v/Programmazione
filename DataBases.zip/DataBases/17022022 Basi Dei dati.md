1. chiavi ed attributi 
	1. Super chiavi 
	2. chiavi	
2. esempio Ricerca chiavi ABDCEF 
   AB --> C, E--> A (fa tutto il percorso passando anche per D)
3. BD fa parte di tutte le chiavi dato che non è derivabile a destra 
4. È un modo compatto per scirvere:
$$A::(BC)$$
$$ A, \ AB, \ AC, \ ABC $$

5. Elemento estraneo:
		   AB -> C appartnente ad F
		   B -> C Appartnente ad F^+ 
		   qunindo A elemento estraneo 

Ci aiuta ad esprimere le super chiavi in forma canonica!



### Tags 
#Databases