## 1. one to one 
- like marraige 
- oppure un codice fiscale
	- una persona ha un codice fiscale, e un codice fiscale è esclusivamente associato ad una pesona.  
nel scrivere le cose in questo modo sintattico possiamo dedurre che la parola relazionale deriva dal algebra lineare.

## 2. one to many 
- un account che fa molti commenti 
- un studente può sostenere più esami **MA NON VICEVERSE** è a senso unico come un diodo!!

## 3. many to many 
- 

### Tags
#Databases 