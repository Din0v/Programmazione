# Data integrity 

 la regola aurea è quella di separare in tabelle distinte. 
 ![[Pasted image 20230507203856.png]]

vedere min [59:57](https://www.youtube.com/watch?v=ztHopE5Wnpc?T=59:57) 


### Tags 
#Databases
