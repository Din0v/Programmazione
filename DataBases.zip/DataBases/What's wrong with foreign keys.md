# quando devo usare o meno le chiavi esterne 
vedi [qui](https://stackoverflow.com/questions/83147/whats-wrong-with-foreign-keys)
Fixed



### Tags 
#Databases