# Dynamic Routes 

si usa per riusicer a passare una variable nel URL alla logica del nostro programma.
