# universal resource identifier 
si usa per configurare flask e dirottarlo verso la mia [[Relational databases]] di scelta. 




### Tags
#Databases 