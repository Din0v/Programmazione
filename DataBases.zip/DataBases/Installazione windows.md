# Installazione windows
1. scarica [qui](https://www.enterprisedb.com/postgresql-tutorial-resources-training?uuid=c70fc67b-ca1f-4dc2-b73b-ccb7367fb6b8&campaignId=Product_Trial_PostgreSQL_15)
2. Installare [PgAdmin](https://www.pgadmin.org/download/pgadmin-4-windows/)
3. python3
4. setting up a virtualenv in python3 
5. VsCode oppure un editor di tua scelta (vim...) 





### Tags
#Databases 