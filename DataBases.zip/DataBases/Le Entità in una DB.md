Cos'è una entità ?

![[Pasted image 20230507195553.png]]

**Caleb** in questa foto è l'entità!

an **entity** can be a person, place thing or an event, quindi è un oggetto nel mondo reale oppure una sua astrazzione 

nome, username e password sono gli [[I Attributi in una DB]]

se prendiamo l'analogia alle [[spreadsheet]] possiamo dire che le entita sono le righe (perciò esistono diverse entità in una tabella che sono correlate 1 a 1 nella realtà) 
un altro nome per le righe sono le [[tuple]]

tuples are rows it's just a mathematical terminology to refer to it 



### Tags 
#Databases