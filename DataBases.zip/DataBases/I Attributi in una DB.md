se prendiamo l'analogia alle [[spreadsheet]] possiamo dire che gli attributi sono le colonne 



### Tags 
#Databases