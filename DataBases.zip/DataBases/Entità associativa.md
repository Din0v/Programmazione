![[Pasted image 20230505204535.png]]

sono le **Bridge tables**, 


### Tags 
#Databases