1. [Lucid App](https://lucid.app/documents) per creare [[ERD]]
2. [Tbls](https://github.com/k1LoW/tbls#install) document a Database easily 
3. [SchemaSpy](https://github.com/schemaspy/schemaspy) database schema analyzer, per creare una mappa relazionale da codice (mysql, postgres... )
4. [Diagrams.net](https://app.diagrams.net/) lo strumento online che ho usato per perfezzionare ciò che alvise ha fatto.
5. [WWW SQL DESIGNER](https://github.com/ondras/wwwsqldesigner) strumento simile a Lucid app ma è offline (da provare)
6. [Dbeaver](https://dbeaver.io/download/?start&os=linux&arch=x86_64) a database manegment tool abbastanza famoso 
7. [Lista di progetti interssante](https://github.com/topics/er-diagram)
8. [progetto simile al nostro](https://github.com/edenroseFR/Web-based-SSIS) webSystemAdmin
9. [Lista progetti](https://github.com/topics/flask-mysqldb)



### Tags 
#Databases