# Video:
1. [Installazione](https://www.youtube.com/watch?v=KuQUNHCeKCk)
2. [Tutorial Esaustivo, separa i route](https://www.youtube.com/watch?v=dam0GPOAvVI&t=4678s)





### Tags
#Databases 
