# ci sono 3 sotto categroie di relazioni 

1. [[Associazioni]],  [[Use Relationship]]
2. [[Aggregazioni]], [[Containement Relationships]]
3. [[Specializzazioni]], [[Inheritance Relationships]]

vedi questo [video](https://www.youtube.com/watch?v=UI6lqHOVHic)




### Tags 
#Databases 
#Class
