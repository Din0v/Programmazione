# Cos'è Postgres ?
dopo aver aggiunto la repository, si installa tramite: 
```bash 
sudo apt install postgresql postgresql-contrib
```

- come **Mysql** è un [[RDBMS]].
- postgres è scalabile e stabile. 
- supporta **[[MVCC]]**: multiversion concurrency control.
- supporta le query complicate e composte. 
- 



### Tags
#Databases 