# Installazione su debian 
1. tramite APT:
``` bash 
sudo apt-get install mysql-server
```

2. installare WorkBench Community: 
``` Bash 
sudo 
```





### Tags
#Databases 