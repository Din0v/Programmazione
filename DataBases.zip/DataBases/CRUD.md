# Create, Read, Update and delete
è un approcio di fare basi dei dati
sono le quattro operazioni basilari di gestione persistente dei dati 



### Tags 
#Databases