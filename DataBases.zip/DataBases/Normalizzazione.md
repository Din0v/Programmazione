# Normalizzazione 1NF 2NF 3NF 4NF... 

- using row order to convey information violates INF
- another type of violation mixes datatypes 
- not including a primary key is a violation of the first normal form (every table we design should have a primary key)
- storing a repeating group of data items on a single row violates the First Normal form.
- *Esempio di chiave composta normalizzata 1NF*
![[Pasted image 20230518190001.png]]
- [[Deletion anomaly]] mitigation 
- third normal form: every Non-key attribute in a table should  depend on the key, the whole key, and nothing but the key 
- [[Boyce - codd]] Normal form 
- 




### Tags 
#Databases 